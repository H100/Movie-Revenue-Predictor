"""
import numpy as np
from numpy.linalg import inv
import matplotlib.pyplot as plt
from sklearn import datasets, linear_model
import sys
from numpy import *
import csv
from collections import Counter
from sklearn.svm import SVR
from sklearn.model_selection import train_test_split
from sklearn.kernel_ridge import KernelRidge
from sklearn import linear_model

#For Classification
from sklearn import svm
from sklearn import metrics
from sklearn import preprocessing
from sklearn import utils

col0 = []#color/bw
col1 = []#director name
col6 = []#actor_2_name
col9 = []#genre
col10 = []#actor_10_name
col13 = []#actor_3_name
col16 = []#language
col17 = []#country
col18 = []#content_rating
cf9 = []
cf10 = []
cf11 = []
cf12 = []
cf13 = []
cf14 = []
cf15 = []
cf16 = []
cf17 = []
cf18 = []
cf19 = []
cf20 = []
cf21 = []
cf22 = []
cf23 = []
cf24 = []


count=0


with open('imdb_movie_dataset.csv', 'r') as csvfile:
	reader = csv.reader(csvfile, delimiter=',')
	for row in reader:
		if '' in row:
			continue
		count += 1
		col0.append(row[0])
		col1.append(row[1])

		cf9.append(row[2])
		cf10.append(row[3])
		cf11.append(row[4])
		cf12.append(row[5])

		col6.append(row[6])

		cf13.append(row[7])
		cf14.append(row[8])#Revenue

		col9.append(row[9])
		col10.append(row[10])

		cf15.append(row[11])
		cf16.append(row[12])

		col13.append(row[13])

		cf17.append(row[14])
		cf18.append(row[15])

		col16.append(row[16])
		col17.append(row[17])
		col18.append(row[18])

		cf19.append(row[19])
		cf20.append(row[20])
		cf21.append(row[21])
		cf22.append(row[22])
		cf23.append(row[23])
		cf24.append(row[24])



print(count)

"""

import numpy as np
import pylab as pl
# Make an array of x values
x = [1, 2, 3, 4, 5]
# Make an array of y values for each x value
y = [1, 4, 9, 16, 25]
pl.scatter(x, y,  color='black')
# use pylab to plot x and y
pl.plot(x, y)
# give plot a title
pl.title("Plot of y vs x")
# make axis labels
pl.xlabel("x axis")
pl.ylabel("y axis")
# set axis limits
pl.xlim(0.0, 7.0)
pl.ylim(0.0, 30.)
# show the plot on the screen
pl.show()


