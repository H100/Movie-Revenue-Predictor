import matplotlib.pyplot as plt
import numpy as np
import matplotlib.patches as mpatches

#data
np.random.seed(42)
data = [0.21,0.32,0.30,0.31]#np.random.rand(5)
names = ['SVM','BAGGING','ADABOOST','KNN']


ax = plt.subplot(111)
width=0.3
bins = list(map(lambda x: x-width/2,range(1,len(data)+1)))
ax.bar(bins,data,width=width)
ax.set_xticks(list(map(lambda x: x, range(1,len(data)+1))))
ax.set_xticklabels(names,rotation=45, rotation_mode="anchor", ha="right")
blue_patch = mpatches.Patch(color='blue', label='f1_score')
plt.legend(handles=[blue_patch])

plt.show()
