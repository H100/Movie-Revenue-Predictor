import matplotlib.pyplot as plt
import numpy as np
import matplotlib.patches as mpatches

#data
np.random.seed(42)
data = [0.768549027534,1.09869746817,0.882570093782,0.843137906652]
names = ['Linear','SVR','Kernelized Ridge','Lasso']


ax = plt.subplot(111)
width=0.3
bins = list(map(lambda x: x-width/2,range(1,len(data)+1)))
ax.bar(bins,data,width=width)
ax.set_xticks(list(map(lambda x: x, range(1,len(data)+1))))
ax.set_xticklabels(names, rotation_mode="anchor", ha="right")
blue_patch = mpatches.Patch(color='blue', label='RATING : RMS Error on regression')
plt.legend(handles=[blue_patch])

plt.show()
